import javax.swing.JFrame;

public class Pong extends JFrame {

	final static int WINDOW_WIDTH = 406;

	final static int WINDOW_HEIGHT = 278;

	public Pong() {

		setSize(WINDOW_WIDTH, WINDOW_HEIGHT);
		setResizable(false);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

		
		GamePanel gamePanel = new GamePanel();
		getContentPane().add(gamePanel);
		gamePanel.setLayout(null);

		setVisible(true);

	}

	public static void main(String[] args) {

		new Pong();

	}
}
